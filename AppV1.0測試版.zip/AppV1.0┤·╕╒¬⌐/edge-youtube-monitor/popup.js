document.addEventListener('DOMContentLoaded', function() {
  console.log('Popup loaded');
});
